let gameState = 'START'; // START, PLAYING, GAMEOVER, REVIVING, LEVEL_WIN, GAME_COMPLETE
let currentLevel = 0;
let levelStartTime = 0;
let levelFinalTime = 0;
let lives = 3;
let pauseTimeOffset = 0; // 用於扣除復活等待的時間

const levels = [
  {
    // 第一關：密集迴廊 (Width: 30)
    path: [[100, 100], [400, 100], [400, 50], [700, 50], [700, 200], [100, 200], [100, 300], [600, 300], [600, 400], [100, 400], [100, 550], [750, 550], [750, 700], [100, 700]],
    start: { x: 100, y: 100 },
    end: { x: 100, y: 700 }
  },
  {
    // 第二關：鋸齒地獄 (Width: 20)
    path: [[50, 50], [150, 50], [150, 150], [50, 150], [50, 250], [250, 250], [250, 50], [350, 50], [350, 350], [50, 350], [50, 450], [450, 450], [450, 50], [550, 50], [550, 550], [50, 550], [50, 650], [650, 650], [650, 50], [750, 50], [750, 750]],
    start: { x: 50, y: 50 },
    end: { x: 750, y: 750 }
  },
  {
    // 第三關：微型處理器結構 (Width: 10) - 極限挑戰
    path: [
      [50, 750], [100, 750], [100, 700], [50, 700], [50, 600], [200, 600], [200, 750], [300, 750], [300, 500], [50, 500], [50, 400], [400, 400], [400, 750], [500, 750], [500, 300], [50, 300], [50, 200], [600, 200], [600, 750], [700, 750], [700, 100], [50, 100], [50, 50], [750, 50]
    ],
    start: { x: 50, y: 750 },
    end: { x: 750, y: 50 }
  }
];

function setup() {
  // 設定畫布為視窗寬高
  createCanvas(windowWidth, windowHeight);
  loadLevel(0);
}

function windowResized() {
  // 當視窗大小改變時，同步調整畫布
  resizeCanvas(windowWidth, windowHeight);
}

function draw() {
  background(20); // 更深的背景色
  drawGrid();    // 繪製背景網格

  // 計算縮放比例與位移，讓 800x800 的內容居中並填滿畫面
  let scaleFactor = min(width / 800, height / 800);
  let offsetX = (width - 800 * scaleFactor) / 2;
  let offsetY = (height - 800 * scaleFactor) / 2;

  // 將滑鼠座標轉換回原始的 800x800 座標系，以便邏輯判定
  let virtualMouseX = (mouseX - offsetX) / scaleFactor;
  let virtualMouseY = (mouseY - offsetY) / scaleFactor;

  push();
  translate(offsetX, offsetY);
  scale(scaleFactor);

  if (gameState === 'START') {
    drawTrack();
    displayMessage(`LEVEL ${currentLevel + 1}`, "請移至綠色起點開始挑戰", 400, 400);
    
    let startPos = levels[currentLevel].start;
    // 判定半徑隨難度縮小
    let startThreshold = max(10, 30 - currentLevel * 10);
    // 偵測是否觸碰起點
    if (dist(virtualMouseX, virtualMouseY, startPos.x, startPos.y) < startThreshold) {
      gameState = 'PLAYING';
      levelStartTime = millis(); // 紀錄開始時間
      pauseTimeOffset = 0;
    }
  } else if (gameState === 'PLAYING') {
    drawTrack();
    checkCollision();
    checkWin(virtualMouseX, virtualMouseY);
    drawProbe(virtualMouseX, virtualMouseY); // 繪製自定義探針
    showLiveTimer(); // 顯示即時計時
  } else if (gameState === 'REVIVING') {
    drawTrack();
    displayMessage("Oops!", `剩下 ${lives} 次復活機會\n移回路徑並點擊繼續`, 400, 400);
  } else if (gameState === 'GAMEOVER') {
    drawTrack();
    displayMessage("GAME OVER", "碰觸到牆壁了！點擊畫面重試", 400, 400);
  } else if (gameState === 'LEVEL_WIN') {
    drawTrack();
    displayMessage("CLEAR!", `成功過關！費時: ${levelFinalTime.toFixed(2)} 秒\n點擊進入下一關`, 400, 400);
  } else if (gameState === 'GAME_COMPLETE') {
    displayMessage("CONGRATULATIONS", `恭喜全破！最後一關費時: ${levelFinalTime.toFixed(2)} 秒`, 400, 400);
  }
  
  pop();
}

function loadLevel(index) {
  currentLevel = index;
  if (index === 0 && gameState === 'GAME_COMPLETE') {
    lives = 3; // 全破重玩才重置生命
  }
}

function drawGrid() {
  stroke(40);
  strokeWeight(1);
  for (let i = 0; i < width; i += 50) line(i, 0, i, height);
  for (let i = 0; i < height; i += 50) line(0, i, width, i);
}

function drawTrack() {
  let lvl = levels[currentLevel];
  
  // 動態計算路徑寬度
  let dynamicWeight = max(10, 30 - currentLevel * 10);

  // 設定霓虹發光特效
  drawingContext.shadowBlur = 15;
  
  let trackColor = color(100, 220, 255); // 科技藍
  drawingContext.shadowColor = 'rgba(0, 200, 255, 0.5)';

  // 繪製路徑
  stroke(trackColor);
  strokeWeight(dynamicWeight);
  strokeCap(ROUND);
  strokeJoin(ROUND);
  noFill();
  beginShape();
  for (let v of lvl.path) {
    vertex(v[0], v[1]);
  }
  endShape();

  // 移除後續圖案的陰影，避免效能下降
  drawingContext.shadowBlur = 0;

  // 動態縮放比例 (呼吸燈效果)
  let pulse = sin(frameCount * 0.1) * 5;

  // 起始點標誌大小也隨路徑縮放
  let markerSize = dynamicWeight + 10 + pulse;

  // 起點 (綠色)
  fill(50, 255, 150);
  noStroke();
  ellipse(lvl.start.x, lvl.start.y, markerSize, markerSize);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(max(10, dynamicWeight/3));
  text("START", lvl.start.x, lvl.start.y);

  // 終點 (紅色)
  fill(255, 50, 100);
  ellipse(lvl.end.x, lvl.end.y, markerSize, markerSize);
  fill(255);
  text("GOAL", lvl.end.x, lvl.end.y);
}

function drawProbe(x, y) {
  // 繪製滑鼠位置的科技感探針
  noFill();
  stroke(255, 255, 0);
  strokeWeight(2);
  ellipse(x, y, 15, 15);
  line(x - 10, y, x + 10, y);
  line(x, y - 10, x, y + 10);
}

function checkCollision() {
  // 1. 檢查是否碰到牆壁 (背景色)
  let c = get(mouseX, mouseY);
  
  // 如果 RGB 三色數值都很低，表示滑鼠目前位於背景牆壁或網格區域
  if (c[0] < 60 && c[1] < 60 && c[2] < 60) {
    if (lives > 0) {
      lives--;
      pauseTimeOffset = millis() - levelStartTime; // 紀錄失敗前的純挑戰時間
      gameState = 'REVIVING';
    } else {
      gameState = 'GAMEOVER';
    }
  }
}

function checkWin(vMouseX, vMouseY) {
  // 檢查是否到達紅色終點範圍
  let endPos = levels[currentLevel].end;
  // 終點判定半徑也隨之縮小
  let winThreshold = max(8, 30 - currentLevel * 10) / 2 + 2;
  if (dist(vMouseX, vMouseY, endPos.x, endPos.y) < winThreshold) {
    levelFinalTime = (millis() - levelStartTime) / 1000; // 計算最終費時
    if (currentLevel < levels.length - 1) {
      gameState = 'LEVEL_WIN';
    } else {
      gameState = 'GAME_COMPLETE';
    }
  }
}

function showLiveTimer() {
  let elapsed;
  if (gameState === 'PLAYING') {
    elapsed = (millis() - levelStartTime) / 1000;
  } else {
    elapsed = pauseTimeOffset / 1000;
  }
  fill(255);
  noStroke();
  textSize(24);
  textAlign(LEFT, TOP);
  text(`TIME: ${elapsed.toFixed(2)}s  LIVES: ${lives}`, 20, 20);
}

function displayMessage(title, sub, x, y) {
  // 繪製半透明黑色背景遮罩，讓文字更清楚
  fill(0, 200);
  stroke(100, 220, 255);
  strokeWeight(2);
  rectMode(CENTER);
  rect(x, y, 500, 150, 10);

  noStroke();
  textAlign(CENTER, CENTER);
  
  fill(100, 220, 255);
  textSize(50);
  text(title, x, y - 20);
  
  fill(200);
  textSize(20);
  text(sub, x, y + 35);
}

function mousePressed() {
  if (gameState === 'GAMEOVER') {
    lives = 3; // 徹底失敗重置生命
    loadLevel(currentLevel); // 重新載入當前關卡
    gameState = 'START';
  } else if (gameState === 'REVIVING') {
    // 點擊後繼續，修正開始時間以接續計時
    levelStartTime = millis() - pauseTimeOffset;
    gameState = 'PLAYING';
  } else if (gameState === 'LEVEL_WIN') {
    loadLevel(currentLevel + 1);
    gameState = 'START';
  } else if (gameState === 'GAME_COMPLETE') {
    loadLevel(0);
    gameState = 'START';
  }
}
