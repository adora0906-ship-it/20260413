let input;
let slider;
let button;
let selectElement;
let webDiv;
let isBouncing = false;
let colors = [
  "#012a4a", "#013a63", "#01497c", "#014f86", "#2a6f97", 
  "#2c7da0", "#468faf", "#61a5c2", "#89c2d9", "#a9d6e5"
];

function setup() {
  createCanvas(windowWidth, windowHeight);
  input = createInput('hello');
  input.position(10, 10);
  input.size(300, 50);
  input.style('font-size', '40px');
  slider = createSlider(15, 80, 30);
  slider.position(330, 25);
  button = createButton('跳動');
  button.position(slider.x + slider.width + 20, 25);
  button.mousePressed(() => isBouncing = !isBouncing);
  
  selectElement = createSelect();
  selectElement.position(button.x + 60, 25);
  selectElement.option('淡江大學', 'https://www.tku.edu.tw');
  selectElement.option('淡江教科系', 'https://www.et.tku.edu.tw');
  selectElement.changed(changeContent);

  webDiv = createDiv();
  webDiv.position(200, 200);
  webDiv.size(windowWidth - 400, windowHeight - 400);
  webDiv.html('<iframe src="https://www.tku.edu.tw" style="width:100%; height:100%; border:none"></iframe>');
}

function draw() {
  background(220);
  let s = slider.value();
  textSize(s);
  textAlign(LEFT, TOP);
  let txt = input.value();
  let w = textWidth(txt);
  
  if (w > 0) {
    for (let y = 100; y < height; y += s + 30) {
      let i = 0;
      for (let x = 0; x < width; x += w + 10) {
        fill(colors[i % colors.length]);
        let dx = 0;
        let dy = 0;
        if (isBouncing) {
          dx = sin(frameCount * 0.1 + y * 0.05) * 10;
          dy = sin(frameCount * 0.1 + x * 0.05) * 10;
        }
        text(txt, x + dx, y + dy);
        i++;
      }
    }
  }
}

function changeContent() {
  let url = selectElement.value();
  webDiv.html('<iframe src="' + url + '" style="width:100%; height:100%; border:none"></iframe>');
}
